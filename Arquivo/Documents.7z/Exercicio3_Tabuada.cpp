#include <stdio.h>
int main(){
	
	int n;
	
	printf("Digite um numero: ");
	scanf("%d",&n);
	
	for(int i = 0; i<= 10;i++){
		printf("%d x %d = %d\n",i,n,i*n);
	}
}
