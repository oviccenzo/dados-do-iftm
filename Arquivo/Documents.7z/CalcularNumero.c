#include <stdio.h>
#include <stdlib.h>
int main(){
	int A, B, Soma;
	
	printf("Digite um numero inteiro: ");
	scanf("%d",&A)
}
