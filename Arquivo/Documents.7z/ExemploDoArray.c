#include "stdio.h"
#include "conio.h"

int main(){
	float notas[5] ={7,8,9.5,9.9,5.2};
	
	printf("Exibindo os valores \n\n");
	printf("notas[0] = %.1 \n",notas[0]);
	printf("notas[1] = %.1 \n",notas[1]);
	printf("notas[2] = %.1 \n",notas[2]);
	printf("notas[3] = %.1 \n",notas[3]);
	printf("notas[4] = %.1 \n",notas[4]);
	
	getch();
	return 0;
}
