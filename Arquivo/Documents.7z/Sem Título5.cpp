#include <stdio.h>

int NUMERO = 987*30;  // Vari�vel, n�o mais uma macro

int main() {
    int *p = &NUMERO;  // Agora p armazena o endere�o de NUMERO
    printf("Numero = %d \n", *p);  // Imprime o valor de NUMERO, que � 987
    return 0;
}

