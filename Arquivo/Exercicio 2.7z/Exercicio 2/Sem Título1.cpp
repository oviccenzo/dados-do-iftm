/* 1� Trabalho da disciplina Algoritmos e Fundamentos da Programa��o II � Outubro/2024
Grupo: Andr� Luiz Dias Moreira RA = 14009670665 � Beltrano Nome Completo RA - Ciclano Nome Completo RA
Status: funciona perfeitamente
Exerc�cio 2 - Este programa tem como finalidade a verifica��o bimestral de um aluno, mostrando sua m�dia anual e sua atual condi��o como aluno;
*/

#include <stdio.h> 																		//Biblioteca principal do C (standard input-output header ou cabe�alho padr�o de entrada/sa�da)
#define TAM 4																			//Definindo um tamanho geral como 4;

	
void f_inicio(){ 																		//Fun��o para imprimir o inicio do c�digo;
	printf("----------BEM VINDO--------------\n");
	printf("\n");
	printf("Iniciando sistema----------------\n");
	printf("---------------------------------\n");
	printf("Carregando por favor aguarde-----\n");
	printf("---------------------------------\n");
	printf("---------------------------------\n");
	printf("Sistema carregado----------------\n");
	printf("\n");
																						//Parte decorativa do c�digo, mudando somente na est�tica;
																						// (\n) pula linha	
}
void f_aguarde(){																		//Fun��o que contem um texto est�tico;
	printf("Por favor aguarde\n");
	printf("Por favor aguarde\n");
	printf("Por favor aguarde\n");
	printf("Por favor aguarde\n");
	printf("Por favor aguarde\n");
	printf("Por favor aguarde\n");
	printf("Por favor aguarde\n");
	printf("Por favor aguarde\n");
	printf("\n");
	printf("\n");
}


float f_media(float bim[], int faltas, float media) {
    float soma = 0;																		//Criei uma variavel local pra somente fazer a soma;
    
    for (int i = 0; i < TAM; i++) {														//fazendo uma soma das notas recebidas na fun��o main;
        soma += bim[i];																	//A cada volta ocorrer� uma soma da nota anterior com sua sucessora;
    }
    media = soma / TAM;																	//Fazendo a media entre a soma das notas bimetrais dividido por 4;
    printf("A media do aluno foi de: %.2f pontos e ",media);							//Imprimindo a media do aluno;
    
	
	if (media >= 7.0 && faltas <= 36) {              									//verificando se o aluno est� aprovado, reprovado ou precisa fazer a prova;
        printf("o aluno esta aprovado. Parabens!!!\n");
    } else if (media >= 4.0 && faltas <= 36) {
        printf("o aluno esta de exame final.\n");
    } else {
        printf("o aluno esta reprovado.\n");
    }
	return(media);
}

int main(){ 																			//Fun��o principal do c�digo;
	
	float bim[TAM],media;																//Declarando as vari�veis loca�s;
	int faltas;

	
	f_inicio();																			//chamei a fun��o inicio para mostrar os carecteres est�ticos;
	printf("Digite as notas dos %d bimestres: ", TAM);
    for (int i = 0; i < TAM; i++) {														//Estrutura de repeti��o para gravar as notas de cada bimestre;
        scanf("%f", &bim[i]);
    }
	printf("\n");
	printf("---Salvando informacoes----------\n");
	printf("\n");
	printf("Agora digite a quantidade de faltas: ");									//Scanf para registrar as faltas do aluno;
	scanf("%d",&faltas);
	printf("\n");														
	printf("---Salvando informacoes----------\n");
	printf("\n");
	printf("\n");
	printf("---Analisando seu rendimento-----\n");
	f_aguarde();																		//Chamei a Fun��o aguarde para est�tica do c�digo;
	media = f_media(bim,media,faltas);													//A vari�vel media recebe os resultados armezanados na fun��o m�dia;
	
	return 0;																			//Finalizando o c�digo;
}
