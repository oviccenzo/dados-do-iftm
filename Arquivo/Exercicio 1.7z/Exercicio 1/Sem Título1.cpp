/* 1� Trabalho da disciplina Algoritmos e Fundamentos da Programa��o II � Outubro/2024
Grupo: Andr� Luiz Dias Moreira RA = 14009670665 � Beltrano Nome Completo RA - Ciclano Nome Completo RA
Status: funciona perfeitamente
Exerc�cio 1 - Este programa tem como finalidade a apura��o de votos similar a uma urna eletronica;
*/

#include <stdio.h> 									//Biblioteca principal do C (standard input-output header ou cabe�alho padr�o de entrada/sa�da)


int f_imprimir(int c1, int c2, int c3, int c4, int vn, int vb){ //Fun��o para imprimir os resultados;
	printf("Carregando resultados por favor aguarde--------\n");
	printf("-----------------------------------------------\n");
	printf("-----------------------------------------------\n");
	printf("TOTAL DE VOTOS: \n");
	printf("Candidato Fernando peixoto com %d votos \n",c1);
	printf("Candidata Paola Soares com %d votos \n",c2);
	printf("Candidata Joana Moreira Silva com %d votos\n",c3);
	printf("Candidato Joao Vitor Almeida com %d votos\n",c4);
	printf("Quantidade de votos nulo foram de %d votos\n",vn);
	printf("Quantidade de votos em branco foram de %d votos\n",vb);
	printf("\n");
	return 0;
}
void f_inicio(){ 									//Fun��o para imprimir o inicio do c�digo;
	printf("----------BEM VINDO----------------------------\n");
	printf("\n");
	printf("Iniciando sistema------------------------------\n");
	printf("-----------------------------------------------\n");
	printf("Carregando por favor aguarde-------------------\n");
	printf("-----------------------------------------------\n");
	printf("-----------------------------------------------\n");
	printf("Sistema carregado------------------------------\n");
	printf("\n");
													//Parte decorativa do c�digo, mudando somente na est�tica;
													// (\n) pula linha	
}
void f_urna(){ 										//Fun��o para imprimir a mensagem da urna;
	printf("Por favor selecione uma das opcoes abaixo: \n");
	printf("\n");
	printf("Pressione 1 para selecionar o candidato: Bernardo peixoto\n");
	printf("\n");
	printf("Pressione 2 para selecionar a candidata: Paola Soares\n");
	printf("\n");
	printf("Pressione 3 para selecionar a candidata: Joana Moreira Silva\n");
	printf("\n");
	printf("Pressione 4 para selecionar o candidato: Joao Vitor Almeida\n");
	printf("\n");
	printf("Pressione 5 para selecionar a opcao votar nulo\n");
	printf("\n");
	printf("Pressione 6 para selecionar a opcao votar em branco\n");
	printf("\n");
	printf("Pressione 0 para encerrar a contacao de votos.");
	printf("\n");
													//parte est�tica: Para maior compreens�o do usu�rio ao escolher a op��o desejada;	
}
void f_erro(){ 										//Fun��o para imprimir uma mensagem de erro;
	printf("ERRO!!!\n");
	printf("\n");
	printf("O numero pressionado nao corresponde a nenhum candidato, voto nulo ou voto em branco!.\n");
	printf("\n");
	f_urna();
}
int main(){ 										// fun��o principal do c�digo
	
	int candidato1=0, candidato2=0, candidato3=0, candidato4=0, voto_nulo=0, voto_branco=0, menu=1, resultado=0;
	
													//declarei todas as vari�veis recebendo 0 com excess�o da menu para que o programa executasse no comando while;
	f_inicio();	
	
																											
	while(menu!=0){  								//Comando while, usado como estrutura de repeti��o (O programa ir� rodar diversas vezes a mesma etapa enquanto a condi��o estabelecida permanecer verdadeira);
	
		printf("-----URNA ELETRONICA ONLINE!!!-----------------\n");
		printf("\n");
					
		f_urna();
		
		scanf("%d",&menu); 						  //Scanf: Utilizado como leitor de dados do fluxo de entrada padr�o stdin(entrada do teclado) que ir� armazenar os dados inseridos dentro da vari�vel desejada;
		printf("\n");
		printf("Opcao selecionada: %d \n",menu); // printf + variavel no final: Imprime uma mensagem na tela armazenada dentro da vari�vel em quest�o;
		printf("\n");
		
		if(menu==0){ 							//Comando If: A id�ia do comando if � verificar se uma dada condi��o � verdadeira ou falsa. Tente pensar como "Se acontecer tal coisa, fa�a isso:";
												//No if em quest�o, est� definindo uma condi��o de que se o bot�o pressionado no menu for 0, ele dever� imprimir os resultados armezados nas vari�veis e encerrar o programa;	
			resultado = f_imprimir(candidato1, candidato2, candidato3, candidato4, voto_nulo, voto_branco);
			printf("Saindo do programa----------\n");
			printf("----------------------------\n");
			printf("----------------------------\n");
			printf("----------------------------\n");
			return 0;
		}
	
		switch (menu){ 							//Comando Switch: � utilizado como uma forma de reduzir a complexidade de v�rios if � else encadeados. Ou seja, ao inv�s de usar 30 ifs e elses utilize switch;
												//No switch em quest�o, est� definido como um menu interativo para armazenar um determinado valor em cada vari�vel, dependendo da op��o que o usu�rio pressionar;
		                   						//Est� configurado em 6 possibilidades, caso o usu�rio digite outro n�mero ap�s o 6 ir� aparecer uma mensagem de erro;
		case 1:
			candidato1 = + 1;
			printf("\n");
			printf("\n");
			printf("\n");
			break;
		case 2:
			candidato2= + 1;
			printf("\n");
			printf("\n");
			printf("\n");
			break;
		case 3:
			candidato3= + 1;
			printf("\n");
			printf("\n");
			printf("\n");
			break;
		case 4:
			candidato4= + 1;
			printf("\n");
			printf("\n");
			printf("\n");
			break;
		case 5:
			voto_nulo= + 1;
			printf("\n");
			printf("\n");
			printf("\n");
			break;
		case 6:
			voto_branco= + 1;
			printf("\n");
			printf("\n");
			printf("\n");
			break;
		default:              						//Mesma mensagem que aparece no inicio da estrutura de repeti��o "While", com altera��o na mensagem "ERRO" informando que pressionou um numero errado;	
			f_erro();
			scanf("%d",&menu);
			
			if(menu==0){ 						//Comando If: A id�ia do comando if � verificar se uma dada condi��o � verdadeira ou falsa. Tente pensar como "Se acontecer tal coisa, fa�a isso:";
				        						//No if em quest�o, est� definindo uma condi��o de que se o bot�o pressionado no menu for 0, ele dever� imprimir os resultados armezados nas vari�veis e encerrar o programa;	
				
				resultado = f_imprimir(candidato1, candidato2, candidato3, candidato4, voto_nulo, voto_branco);
				printf("Saindo do programa----------\n");
				printf("----------------------------\n");
				printf("----------------------------\n");
				printf("----------------------------\n");
				return 0;
			}
			
			printf("\n");
			printf("Opcao selecionada: %d \n",menu);
			printf("\n");
			printf("\n");
			break;
		}	
	}		
}
