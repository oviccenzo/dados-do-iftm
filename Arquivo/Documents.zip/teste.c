#include <stdio.h>

int main(){
	printf("ola mundo");
	return 0;
}
