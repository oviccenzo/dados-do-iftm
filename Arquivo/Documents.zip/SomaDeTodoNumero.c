#include <stdio.h>
#include <math.h>

int main(){
	
	int a,b,c,d,e;
	
	printf("Digite numero a: ");
	scanf("%d",&a);
	
	printf("Digite numero b: ");
	scanf("%d",&b);
	
	printf("Digite numero c: ");
	scanf("%d",&c);
	
	printf("Digite numero e: ");
	scanf("%d",&d);
	
	printf("Digite numero d: ");
	scanf("%d",&e);
	
	int soma = a+b+c+d+e;
	
	printf("O reultado �: %d",soma);
	
	return 0;
}
