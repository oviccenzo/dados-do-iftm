#include <stdio.h>
int main(){
	
	int notaDoTrabalho, notaDaprova;
	
	printf("Digite a nota do trabalho: ");
	scanf("%d",&notaDoTrabalho);
	printf("Digite a nota da prova: ");
	scanf("%d",&notaDaprova);
	
	
	
	
	if(nota < 0){
		printf("aprovado");
	}
}
