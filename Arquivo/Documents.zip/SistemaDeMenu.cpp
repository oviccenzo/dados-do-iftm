#include <stdio.h>
int main(){
	
	
	char menu,inserir,editar,remove;
	
	while(menu){
		printf("ler opcao: ");
		scanf("%c",menu)
		
		swith(menu){
			case 1:
				inserir++;
			case 2:
				editar++;
			case 3:
				editar++;
			case 4:
				sair++;
		}
	}
}
