#include <stdio.h>
int main(){
	
	int x,y,z;
	
	x = y = 10;
	printf("O valor de x �: %d\n",x);
	printf("O valor de y �: %d\n\n",y);
	
	
	z = ++x;
	printf("O valor de x �: %d\n",x);
	printf("O valor de y �: %d\n",y);
	printf("O valor de z �: %d\n\n",z);
	
	x = -x;
	printf("O valor de x �: %d\n",x);
	printf("O valor de y �: %d\n",y);
	printf("O valor de z �: %d\n\n",z);
	
	y *= x + 1;
	printf("O valor de x �: %d\n",x);
	printf("O valor de y �: %d\n",y);
	printf("O valor de z �: %d\n\n",z);
	
	y++;
	printf("O valor de x �: %d\n",x);
	printf("O valor de y �: %d\n",y);
	printf("O valor de z �: %d\n\n",z);
	
	x = x + y - (z--);
	printf("O valor de x �: %d\n",x);
	printf("O valor de x �: %d\n",y);
	printf("O valor de x �: %d\n\n",z);
}
