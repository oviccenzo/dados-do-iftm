public class exemplo2 {

    public static void main(String[] args) {
        int x,y;

        x = 5;
        y = 2*x;
        System.out.println(x);
        System.out.println(y);
    }
}
