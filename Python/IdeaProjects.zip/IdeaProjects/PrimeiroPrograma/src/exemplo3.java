public class exemplo3 {

    public static void main(String[] args) {

        //declaração das variaveis
        double b,B,area,h;

        //inicialização
        b = 6.0;
        B = 8.0;
        h = 5.0;

        //processamento(resolvendo o problema)
        area = (b + B) / 2.0 *h;

        //saida de dados
        System.out.println(area);
    }
}
