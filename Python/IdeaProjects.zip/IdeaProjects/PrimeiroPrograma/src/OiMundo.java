public class OiMundo {


    public static void main(String[] args){

    System.out.print("Hello World!!!\n");
    //System.err.println("Bem Vindo ao disciplina de POO");
        System.out.println("Bem Vindo ao disciplina de POO");

    }

}
