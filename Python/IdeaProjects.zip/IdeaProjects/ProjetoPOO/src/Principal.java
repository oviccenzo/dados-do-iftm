import java.util.Locale;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {

        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);

        double p,aX,bX,cX, aY, bY, cY,areaX, areaY;
        System.out.println("Entre com as medidas do Triangulo X (lado a, labo b e lado c): ");
        aX = sc.nextDouble();
        bX = sc.nextDouble();
        cX = sc.nextDouble();
        System.out.println("Entre com as medidas do Triangulo Y (lado a, lado b e lado c): ");
        aY = sc.nextDouble();
        bY = sc.nextDouble();
        cY = sc.nextDouble();

        p = (aX+bX+cX)/2;
        areaX = Math.sqrt(p*(p-aX)*(p-bX)*(p-cX));

        p = (aY+bY+cY)/2;
        areaY = Math.sqrt(p*(p-aY)*(p-bY)*(p-cY));

        System.out.printf("Área do triangulo X: %.4f %n", areaX);
        System.out.printf("Área do triangulo Y: %.4f %n", areaY);

        if(areaX > areaY){
            System.out.println("Triangulo com maior área: X");
        }else if(areaY > areaX){
            System.out.println("Triangulo com maior área: Y");
        }else{
            System.out.println("Triangulo X e Y possui as areas iguais");
        }
        sc.close();
    }
}
