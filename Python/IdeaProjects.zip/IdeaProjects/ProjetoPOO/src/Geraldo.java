import entidades.Triangulo;

import java.util.Locale;
import java.util.Scanner;

public class Geraldo {

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);

        Triangulo x,y;
        double areaX, areaY;
        x = new Triangulo();
        y = new Triangulo();
        System.out.println("Entre com as medidas do Triangulo X (lado a, labo b e lado c): ");
        x.a = sc.nextDouble();
        x.b = sc.nextDouble();
        x.c = sc.nextDouble();
        System.out.println("Entre com as medidas do Triangulo Y (lado a, lado b e lado c): ");
        y.a = sc.nextDouble();
        y.b = sc.nextDouble();
        y.c = sc.nextDouble();
        areaX = x.area();
        areaY = y.area();

//        System.out.printf("Área do triangulo X: %.4f %n", areaX);
//        System.out.printf("Área do triangulo Y: %.4f %n", areaY);

        if (areaX > areaY) {
            System.out.println("Triangulo com maior área: X");
        } else if (areaY > areaX){
            System.out.println("Triangulo com maior área: Y");
        }else{
            System.out.println("Triangulo X e Y possui as areas iguais");
        }
        sc.close();
    }
}
