package entidades;

public class Conta {

    //atributos da classe
    private int numero;
    private String titular;
    private double saldo;

    //metodos construtores
    public Conta(int numero, String titular) {
        this.numero = numero;
        this.titular = titular;
    }

    public Conta(int numero, String titular, double depositoInicial) {
        this.numero = numero;
        this.titular = titular;
        //this.saldo = depositoInicial;
        this.depositar(depositoInicial);
    }
    public void depositar(double quantia){
        this.saldo += quantia;
    }

    public void sacar(double quantia){
        //this.saldo = this.saldo  - (quantia + 5.0);
        this.saldo -= quantia + 5.0;
    }

    //metodos get e set
    public int getNumero() {
        return numero;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String novotitular) {
        this.titular = novotitular;
    }

    public double getSaldo() {
        return saldo;
    }

    @Override
    public String toString() {
        return "Conta{" +
                "numero=" + numero +
                ", titular='" + titular + '\'' +
                ", saldo=" + String.format("%.2f", saldo) +
                '}';
    }
}
