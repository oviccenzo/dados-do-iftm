import entidades.Conta;

import java.util.Locale;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);

        Conta c;
        System.out.print("Entre com o numero da conta: ");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.print("Entre com nome do titular: ");
        String titular = sc.nextLine();
        System.out.print("Voce deseja realizar um deposito inicial (s/n)? ");
        char opcao = sc.next().charAt(0);
        if(opcao == 's' || opcao == 'S'){
            System.out.print("Entre com valor do deposito inicial: ");
            double valorDeposito = sc.nextDouble();
            c = new Conta(numero, titular, valorDeposito);
        }else{
            c = new Conta(numero, titular);
        }
        System.out.println("Dados da Conta:");
        System.out.println(c);

        System.out.print("Entre com um valor para deposito:");
        //double valorDeposito = sc.nextDouble();
        //c.depositar(valorDeposito);
        c.depositar(sc.nextDouble());
        System.out.println("Atualização dos dados da conta: ");
        System.out.println(c);
        System.out.print("Entre com um valor para saque: ");
        //double valorSaque = sc.nextDouble();
        //c.sacar(valorSaque);
        c.sacar(sc.nextDouble());
        System.out.println("Atualização dos dados da conta: ");
        System.out.println(c);

    }
}
